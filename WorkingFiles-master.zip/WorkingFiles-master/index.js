require ("./filename");
require ("./filebirth");
console.log("My file");